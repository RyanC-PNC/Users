# Users Application

This is a Java Spring Boot REST API project for managing user entities. It provides CRUD operations (Create, Read, Update, Delete) for users.

## Features

- Add a new user
- Retrieve all users
- Retrieve a user by ID
- Update a user
- Delete a user

## Status

All tests are passing and the project is fully documented.

## Tests

The project includes unit tests for the following components:
- `UsersController` class
- `UserService` class
- `UserRepository` interface