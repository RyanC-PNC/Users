package com.example.users.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.users.entity.User;

/**
 * Repository interface for managing User entities. Provides CRUD operations for
 * User objects.
 *
 * @author Chris Ryan
 * @since 1.0
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

}