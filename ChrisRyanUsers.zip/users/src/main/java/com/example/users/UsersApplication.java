package com.example.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The main class that starts the Users application.
 *
 * @author Chris Ryan
 * @since 1.0
 */
@SpringBootApplication
public class UsersApplication {

	/**
	 * The main method that starts the Users application.
	 *
	 * @param args The command line arguments passed to the application.
	 */
	public static void main(String[] args) {
		SpringApplication.run(UsersApplication.class, args);
	}

}
