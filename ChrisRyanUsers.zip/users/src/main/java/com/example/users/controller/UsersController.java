package com.example.users.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.users.entity.User;
import com.example.users.service.UserService;

/**
 * REST controller for managing User entities.
 *
 * @author Chris Ryan
 * @since 1.0
 */
@RestController
public class UsersController {
	/**
	 * Service to execute CRUD operations against
	 */
	@Autowired
	UserService userService;

	/**
	 * Responds with a ping-pong message to check if the server is running.
	 *
	 * @return A string message "pong" indicating a successful response.
	 * @since 1.0
	 */
	@GetMapping("/ping")
	public String pingPong() {
		return "pong";
	}

	/**
	 * Adds a new User to the system.
	 *
	 * @param user The User object to be added.
	 * @since 1.0
	 */
	@PostMapping("/new")
	public void addUser(@RequestBody User user) {
		this.userService.addUser(user);
	}

	/**
	 * Retrieves all Users from the system.
	 *
	 * @return A list of all User objects.
	 * @since 1.0
	 */
	@GetMapping("/users")
	public List<User> getAllUsers() {
		return this.userService.findAllUsers();
	}

	/**
	 * Retrieves a specific User by their ID.
	 *
	 * @param id The ID of the User to retrieve.
	 * @return The User object matching the given ID.
	 * @since 1.0
	 */
	@GetMapping("/findbyid/{id}")
	public User geUserById(@PathVariable long id) {
		return this.userService.findUserByID(id);
	}

	/**
	 * Deletes a User from the system by their ID.
	 *
	 * @param id The ID of the User to delete.
	 * @since 1.0
	 */
	@DeleteMapping("/delete/{id}")
	public void deleteUser(@PathVariable long id) {
		this.userService.deleteUser(id);
	}

	/**
	 * Updates an existing User with new information.
	 *
	 * @param id          The ID of the User to update.
	 * @param updatedUser The updated User object.
	 * @return The updated User object.
	 * @since 1.0
	 */
	@PutMapping("/user/{id}")
	public User updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
		return this.userService.updateUser(id, updatedUser);
	}
}