package com.example.users.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.users.entity.User;
import com.example.users.repository.UserRepository;

/**
 * Service class for managing User entities.
 *
 * @author Chris Ryan
 * @since 1.0
 */
@Service
public class UserService {

	/**
	 * UserRepository to manage User entity data
	 */
	@Autowired
	private UserRepository userRepository;

	/**
	 * Retrieves all Users from the repository.
	 *
	 * @return A list of all User objects.
	 * @since 1.0
	 */
	public List<User> findAllUsers() {
		return this.userRepository.findAll();
	}

	/**
	 * Retrieves a specific User by their ID from the repository.
	 *
	 * @param id The ID of the User to retrieve.
	 * @return The User object matching the given ID.
	 * @since 1.0
	 * @throws RuntimeException if the User is not found.
	 */
	public User findUserByID(long id) {
		return this.userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found: " + id));
	}

	/**
	 * Adds a new User to the repository.
	 *
	 * @param u The User object to be added.
	 * @since 1.0
	 */
	public void addUser(User u) {
		this.userRepository.save(u);
	}

	/**
	 * Updates an existing User in the repository with new information.
	 *
	 * @param id          The ID of the User to update.
	 * @param updatedUser The updated User object.
	 * @return The updated User object.
	 * @since 1.0
	 * @throws RuntimeException if the User is not found.
	 */
	public User updateUser(Long id, User updatedUser) {
		User existingUser = this.userRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("User not found: " + id));

		if (existingUser != null) {
			return this.userRepository.save(updatedUser);
		}
		throw new RuntimeException("User not found: " + id);
	}

	/**
	 * Deletes a User from the repository by their ID.
	 *
	 * @param id The ID of the User to delete.
	 * @since 1.0
	 */
	public void deleteUser(long id) {
		this.userRepository.deleteById(id);
	}
}