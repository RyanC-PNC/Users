package com.example.users.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Represents a User entity in the application.
 *
 * @author Chris Ryan
 * @since 1.0
 */
@Entity
@Table(name = "\"user\"")
public class User {
	/**
	 * The unique ID for the User
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;

	/**
	 * The first and last name of the User
	 */
	@Column(name = "name")
	private String name;

	/**
	 * The email address for the User
	 */
	@Column(name = "email")
	private String email;

	/**
	 * The biography for the User
	 */
	@Column(name = "bio")
	private String bio;

	/**
	 * The URL for the User
	 */
	@Column(name = "url")
	private String url;

	/**
	 * Default constructor for the User class.
	 */
	public User() {

	}

	/**
	 * Constructs a User object with the specified attributes.
	 *
	 * @param id    The ID of the user.
	 * @param name  The name of the user.
	 * @param email The email address of the user.
	 * @param bio   The biography of the user.
	 * @param url   The URL of the user.
	 */
	public User(long id, String name, String email, String bio, String url) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.bio = bio;
		this.url = url;
	}

	/**
	 * Retrieves the ID of the user.
	 *
	 * @return The ID of the user.
	 * @since 1.0
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * Sets the ID of the user.
	 *
	 * @param id The new ID of the user.
	 * @since 1.0
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Retrieves the name of the user.
	 *
	 * @return The name of the user.
	 * @since 1.0
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Sets the name of the user.
	 *
	 * @param name The new name of the user.
	 * @since 1.0
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Retrieves the email address of the user.
	 *
	 * @return The email address of the user.
	 * @since 1.0
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * Sets the email address of the user.
	 *
	 * @param email The new email address of the user.
	 * @since 1.0
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Retrieves the biography of the user.
	 *
	 * @return The biography of the user.
	 * @since 1.0
	 */
	public String getBio() {
		return this.bio;
	}

	/**
	 * Sets the biography of the user.
	 *
	 * @param bio The new biography of the user.
	 * @since 1.0
	 */
	public void setBio(String bio) {
		this.bio = bio;
	}

	/**
	 * Retrieves the URL of the user.
	 *
	 * @return The URL of the user.
	 * @since 1.0
	 */
	public String getUrl() {
		return this.url;
	}

	/**
	 * Sets the URL of the user.
	 *
	 * @param url The new URL of the user.
	 * @since 1.0
	 */
	public void setUrl(String url) {
		this.url = url;
	}
}
