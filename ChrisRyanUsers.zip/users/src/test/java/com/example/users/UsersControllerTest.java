package com.example.users;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.users.controller.UsersController;
import com.example.users.entity.User;
import com.example.users.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Unit tests for the UsersController class.
 *
 * @author Chris Ryan
 * @since 1.0
 */
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class UsersControllerTest {

	/**
	 * UserService to mock data with
	 */
	@Mock
	private UserService userService;

	/**
	 * Controller for injecting
	 */
	@InjectMocks
	private UsersController usersController;

	/**
	 * Mocked servlet for testing
	 */
	@Autowired
	private MockMvc mockMvc;

	/**
	 * Object mapper for Json management
	 */
	private ObjectMapper objectMapper;

	/**
	 * Setup method to initialize necessary objects before each test.
	 *
	 * @since 1.0
	 * @throws JsonProcessingException if an error occurs during JSON processing.
	 * @throws Exception               if an error occurs during setup.
	 */
	@BeforeEach
	public void setup() throws JsonProcessingException, Exception {
		this.objectMapper = new ObjectMapper();

		User user = new User(1, "John", "john@example.com", "Bio", "http://example.com");

		this.mockMvc
				.perform(MockMvcRequestBuilders.post("/new").contentType(MediaType.APPLICATION_JSON)
						.content(this.objectMapper.writeValueAsString(user)))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	/**
	 * Test case for retrieving all users.
	 *
	 * @since 1.0
	 * @throws Exception if an error occurs during the test.
	 */
	@Test
	public void testGetAllUsers() throws Exception {
		this.mockMvc.perform(MockMvcRequestBuilders.get("/users")).andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$[0].name").value("John"))
				.andExpect(MockMvcResultMatchers.jsonPath("$[0].email").value("john@example.com"));
	}

	/**
	 * Test case for deleting a user.
	 *
	 * @since 1.0
	 * @throws Exception if an error occurs during the test.
	 */
	@Test
	public void testDeleteUser() throws Exception {
		long userId = 1;

		this.mockMvc.perform(MockMvcRequestBuilders.delete("/delete/{id}", userId))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	/**
	 * Test case for updating a user.
	 *
	 * @since 1.0
	 * @throws Exception if an error occurs during the test.
	 */
	@Test
	public void testUpdateUser() throws Exception {
		long userId = 1;
		User updatedUser = new User(userId, "Updated Name", "updated@example.com", "Updated Bio",
				"http://example.com/updated");
		this.mockMvc
				.perform(MockMvcRequestBuilders.put("/user/{id}", userId).contentType(MediaType.APPLICATION_JSON)
						.content(this.objectMapper.writeValueAsString(updatedUser)))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Updated Name"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.email").value("updated@example.com"));
	}
}
